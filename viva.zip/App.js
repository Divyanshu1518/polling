import React, { useState, useRef } from 'react';
import './App.css';

const ProductManagement = () => {
  const [products, setProducts] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const formRef = useRef(null);

  const handleProductCreate = (e) => {
    e.preventDefault();

    const formData = new FormData(formRef.current);
    const productData = Object.fromEntries(formData.entries());

    if (editingProduct !== null) {
      setProducts((prevProducts) => {
        const updatedProducts = [...prevProducts];
        updatedProducts[editingProduct] = productData;
        return updatedProducts;
      });
      setEditingProduct(null);
    } else {
      setProducts((prevProducts) => [...prevProducts, productData]);
    }

    formRef.current.reset();
  };

  const handleProductEdit = (index) => {
    setEditingProduct(index);
    const selectedProduct = products[index];
    formRef.current.elements.name.value = selectedProduct.name;
    formRef.current.elements.description.value = selectedProduct.description;
    formRef.current.elements.price.value = selectedProduct.price;
    formRef.current.elements.quantity.value = selectedProduct.quantity;
  };

  const handleProductDelete = (index) => {
    setProducts((prevProducts) => {
      const updatedProducts = [...prevProducts];
      updatedProducts.splice(index, 1);
      return updatedProducts;
    });
  };

  return (
    <div className="product-management">
      <h1>Product Management</h1>
      <form className="product-form" onSubmit={handleProductCreate} ref={formRef}>
        <input type="text" name="name" placeholder="Product Name" required />
        <textarea name="description" placeholder="Description" required />
        <input type="number" name="price" placeholder="Price" required />
        <input type="number" name="quantity" placeholder="Quantity" required />
        <button type="submit">{editingProduct !== null ? 'Update Product' : 'Create Product'}</button>
      </form>

      <h2>Product Details</h2>
      <ul className="product-list">
        {products.map((product, index) => (
          <li key={index} className="product-item">
            <div className="product-info">
              <strong>{product.name}</strong>
              <p>{product.description}</p>
            </div>
            <div className="price-quantity">
              <span>Price: ${product.price}</span>
              <span>Quantity: {product.quantity}</span>
            </div>
            <div className="button-container">
              <button className="edit-button" onClick={() => handleProductEdit(index)}>
                Edit
              </button>
              <button className="delete-button" onClick={() => handleProductDelete(index)}>
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductManagement;
